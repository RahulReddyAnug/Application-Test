﻿using OfferEntities;
using OfferServiceHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application_Test.Controllers
{
    public class Offer : ApiController
    {
        // GET api/<controller>
        [HttpGet]
        public HttpResponseMessage GetAllProducts()
        {
            
            OfferService ofrservice = new OfferService();
            List<Product> prs= ofrservice.GetAllProducts();
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, prs);
            return response;
        }

        [HttpGet]
        public HttpResponseMessage GetTodaysOffers()
        {

            OfferService ofrservice = new OfferService();
            List<OfferEntities.Offer> offers = ofrservice.GetTodaysOffers();
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, offers);
            return response;
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}