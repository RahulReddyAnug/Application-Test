﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            LoopingMethod();
            ReverseStringMethod();

        }

        public static void LoopingMethod()
        {
            for(int i=1;i<=100; i++)
            {
                string result = "";
                if((i % 3) == 0)
                {
                    result = "fizz";
                }
                if ((i % 5) == 0)
                {
                    result = result + "buzz";
                }

                if(result != "")
                {
                    Console.WriteLine(result);
                }
            }
        }

        public static void ReverseStringMethod()
        {
            string text = "abcdef";
            string result = "";

            for(int i=text.Length - 1; i >= 0; i--)
            {
                result = result + text[i];
            }
            Console.WriteLine(result);
        
        }
    }
}

