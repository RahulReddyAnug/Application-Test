﻿using OfferEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfferServiceHandler
{
    public class OfferService
    {
        List<Product> Inventory = new List<Product>();
        public OfferService()
        {
            
            Product p1 = new Product();
            p1.ProductName = "P1";
            p1.Price = 1000;
            p1.Description = "P1   desc";
            Inventory.Add(p1);
            Product p2 = new Product();
            p2.ProductName = "P2";
            p2.Price = 200;
            p2.Description = "P2   desc";
            Inventory.Add(p2);
            Product p3 = new Product();
            p3.ProductName = "P3";
            p3.Price = 400;
            p3.Description = "P3   desc";
            Inventory.Add(p3);
            Product p4 = new Product();
            p4.ProductName = "P4";
            p4.Price = 700;
            p4.Description = "P4   desc";
            Inventory.Add(p4);
            Product p5 = new Product();
            p5.ProductName = "P5";
            p5.Price = 600;
            p5.Description = "P5   desc";
            Inventory.Add(p5);
            Product p6 = new Product();
            p6.ProductName = "P6";
            p6.Price = 800;
            p6.Description = "P16   desc";
            Inventory.Add(p6);
        }


        public List<Product> GetAllProducts()
        {
            return Inventory;
        }

        public List<Offer> GetTodaysOffers()
        {
            try
            {


                List<Offer> lstOffer = new List<Offer>();

                Offer ofr = new Offer();
                ofr.OfferName = "ComboPackage1";
                List<Product> p1 = new List<Product>();
                p1 = Inventory.OrderBy(s => s.ProductName).Take(3).ToList();
                ofr.products = p1;
                lstOffer.Add(ofr);
                Offer ofr1 = new Offer();
                ofr1.OfferName = "ComboPackage1";
                List<Product> p2 = new List<Product>();
                p2 = Inventory.OrderBy(s => s.ProductName).Take(3).ToList();
                ofr1.products = p2;
                lstOffer.Add(ofr1);

                Offer ofr2 = new Offer();
                ofr2.OfferName = "ComboPackage1";
                List<Product> p3 = new List<Product>();
                p3 = Inventory.OrderBy(s => s.ProductName).Take(3).ToList();
                ofr2.products = p3;
                lstOffer.Add(ofr2);

                return lstOffer;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }


        //p1.ProductName = ""




    }


}
