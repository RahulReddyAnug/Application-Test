﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OfferEntities
{
    public class Offer
    {
        public string OfferName { get; set; }
        public List<Product> products { get; set; }
    }
}
